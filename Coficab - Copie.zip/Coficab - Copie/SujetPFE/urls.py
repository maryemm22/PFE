from django.urls import path
from SujetPFE.views import *

urlpatterns = [
    path('', loginU, name='loginU'),
    path('ajouter/', ajouter, name="ajouter"),
    path('modifier/<int:id>/', modifier, name="modifier"),
    path('backModifier/<int:id>/', backModifier, name="backModifier"),
    path('supprimer/<int:id>/', supprimer, name="supprimer"),
    path('creation/', create_utilisateur, name='creation'),
    path('creationBack/', createBack, name='createBack'),
    path('index/', index, name='index'),
    path('loginBack/', loginBack, name="loginBack"),
    path('profile/<str:username>/', profile, name="profile"),
    path('deconnexion/', deconnexion, name="deconnexion"),
    path('mail/', Email_Envoyer, name="mail"),
    path('msg/', msg, name="msg"),
    path('indicateur/', article, name="indicateur"),
    path('interventionPagination/<str:username>/', interventionPagination, name="intervention"),
    path('intervention/<str:username>/', intervention_enreg, name="intervention_enreg"),
    path('intervBack/<str:username>/', interv_backend, name="interv_backend"),
    path('demande/<str:username>/', Demande, name="demande"),

]
