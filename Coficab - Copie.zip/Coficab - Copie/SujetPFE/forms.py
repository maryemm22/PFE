from django import forms
from .models import *


class InterventionForm(forms.ModelForm):
    class Meta:
        model = InterventionP
        fields = ('tache_effectuee', 'username')
