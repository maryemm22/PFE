from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.db import models

from notifications.base.models import AbstractNotification
from swapper import swappable_setting

# Create your models here.
from Coficab import settings


class PressionE(models.Model):
    Ext1_min_Pr = models.FloatField(default=76.2)
    Ext1_avg_Pr = models.FloatField(default=505.7)
    Ext1_max_Pr = models.FloatField(default=527.3)

    Ext2_min_Pr = models.FloatField(default=48.7)
    Ext2_avg_Pr = models.FloatField(default=533.0)
    Ext2_max_Pr = models.FloatField(default=579.5)


class VitesseE(models.Model):
    Ext1_min_V = models.FloatField(default=1.4)
    Ext1_avg_V = models.FloatField(default=54.1)
    Ext1_max_V = models.FloatField(default=66.3)

    Ext2_min_V = models.FloatField(default=1.9)
    Ext2_avg_V = models.FloatField(default=67.6)
    Ext2_max_V = models.FloatField(default=82.9)

    Min_line_V = models.FloatField(default=110.0)
    Avg_Line_V = models.FloatField(default=954.6)
    Max_Line_V = models.FloatField(default=1002.1)


class TemperatureE(models.Model):
    Ext1_min_T = models.FloatField(default=500.0)
    Ext1_avg_T = models.FloatField(default=500.0)
    Ext1_max_T = models.FloatField(default=500.0)

    Ext2_min_T = models.FloatField(default=500.0)
    Ext2_avg_T = models.FloatField(default=500.0)
    Ext2_max_T = models.FloatField(default=500.0)


class TensionEx(models.Model):
    Min_Brake_T = models.FloatField(default=10.2)
    Avg_Brake_T = models.FloatField(default=16.0)
    Max_Brake_T = models.FloatField(default=30.9)


class InterventionP(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    date_Intervention = models.DateField()
    tache_effectuee = models.TextField()
    panneM = models.CharField(max_length=100)


################################################################
class Ligne_Extr(models.Model):
    nom_Extr = models.CharField(max_length=50)


class Indicateurs(models.Model):
    name = models.CharField(max_length=30)
    ligne = models.ForeignKey(Ligne_Extr, on_delete=models.CASCADE)
    temperature = models.PositiveIntegerField()
    vitess = models.IntegerField()
    tension = models.IntegerField()
    pression = models.IntegerField()
    couleur = models.IntegerField()


class NotificationUsers(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, null=True, related_name='sender_notification')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recipient_notification')
    messageUser = models.TextField()
    readNotify = models.BooleanField(default=False)
    recieved_date = models.DateTimeField(auto_now_add=True)
