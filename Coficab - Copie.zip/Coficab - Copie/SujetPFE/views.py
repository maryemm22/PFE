from django.contrib.auth import authenticate, login, logout
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, HttpResponseRedirect, request
from django.shortcuts import render, redirect
import matplotlib.pyplot as plt
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
import dash
import dash_core_components as dcc
import dash_html_components as html
from .models import *
from .tasks import send_email_task


##########################################################################################################
# Gestion des utilisateurs
##########################################################################################################

# liste des utilisateurs que sont utlisent l'application

def index(request):
    # var = models.UtilisateurC.objects.all()
    var1 = User.objects.all()
    return render(request, 'liste.html', {'list': var1})


# page :formulaire d'ajouter

def ajouter(request):
    return render(request, 'ajouter.html')


"""def insertion(request):
    v1 = request.POST.get('Nom_Prenom', False)
    v2 = request.POST.get('mail', False)
    v3 = request.POST.get('poste', False)
    v4 = request.POST.get('departement', False)
    insr = models.UtilisateurC()
    insr.Nom_Prenom = v1
    insr.Adr_mail = v2
    insr.poste = v3
    insr.departement = v4
    insr.save()
    return HttpResponseRedirect('/index')"""


# afficher les données à  modifier

def modifier(request, id):
    # data = models.UtilisateurC.objects.filter(id=id)
    data = User.objects.filter(id=id)
    return render(request, 'modifier.html', {'idU': id, 'data': data[0]})


# modification des données

def backModifier(request, id):
    new = User.objects.create_user(request.POST['username'],
                                   request.POST['email'],
                                   request.POST['password'])

    new.first_name = request.POST['first_name']
    new.last_name = request.POST['last_name']
    """new = User(id=id, Nom_Prenom=request.POST.get('username', False),
                              mail=request.POST.get('email', False), poste=request.POST.get('poste', False),
                              departement=request.POST.get('departement', False))"""
    new.save()
    return HttpResponseRedirect('/index')


def supprimer(request, id):
    var = User(id=id)
    var.delete()
    return HttpResponseRedirect('/index')


#################################################################################################
# Ajouter des users (table User)
#################################################################################################

def create_utilisateur(request):
    return render(request, 'creation_Utilisateurs.html', {})


def createBack(request):
    try:
        var1 = User.objects.create_user(request.POST['username'],
                                        request.POST['email'],
                                        request.POST['password'])

        var1.first_name = request.POST['first_name']
        var1.last_name = request.POST['last_name']
        var1.save()
        return HttpResponseRedirect('/index')
    except:
        return HttpResponse('user existe ')


############################################################################################
# authentification
############################################################################################

def loginU(request):
    return render(request, 'login.html')


def loginBack(request):
    u = request.POST['username']
    p = request.POST['password']
    # vérifions si les données sont correctes
    resultat = authenticate(username=u, password=p)
    if resultat is not None:
        print('login')
        login(request, resultat)
        lien = '/profile/' + str(resultat)  # resultat contient username (retourner profile)

        return HttpResponseRedirect(lien)
    else:
        messages.error(request, "Veuillez confirmer le mot de passe ou le  nom d’utilisateur")
        return redirect('/')


def profile(request, username):
    return render(request, 'profile.html', {'u': username})


def deconnexion(request):
    logout(request)
    return redirect('/')


#########################################################################
# email
#########################################################################
# message
########################################################################


"""
def mail(request):
    rec_email = "kalboussimeriem@gmail.com"
    sender_email = "hammamisiwar.m16@gmail.com"
    password = "SIwar@1996"
    message = "hello"
    # type d'addresse est gmail = smtp.gmail.com / yahoo = smtp.yahoo.com
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, password)
    print("email envoyer avec succès")
    server.sendmail(sender_email, rec_email, message)
    print("email has been ", rec_email)
    return render(request, 'te.html')"""


def msg(request):
    return render(request, 'msg.html')


# lpus condition d'une panne
def Email_Envoyer(request):
    send_email_task()
    return HttpResponse("yesTest")


def article(request):
    return render(request, 'Indicateurs.html')



################################################################
# pagination
################################################################
def interventionPagination(request, username):
    user = User.objects.get(username=username)  # selectionne les données de la table User
    inter = InterventionP.objects.filter(username=user)  # selectionner les données de la table intervention
    dict = {'u1': user, 'u2': inter}
    return render(request, 'Intervention.html', dict)
    #return redirect('/', dict)


################################################################

def intervention_enreg(request, username):

    return render(request, 'Enreg_interv.html', {'us': username})


def interv_backend(request, username):
    u = InterventionP()
    user = User.objects.get(username=username)
    u.date_Intervention = request.POST.get('date_Intervention')
    u.tache_effectuee = request.POST.get('tache_effectuee')
    u.panneM = request.POST.get('panneM')
    u.username = user
    u.save()
    return render(request, 'Enreg_Interv.html', {'username': username})


###################################################################
# notification
###################################################################

# def notificationUser(request):
# return render(request, 'alerte.html')


###############################################
# search
###################################################
def post_list(request):
    today = timezone.now.date()
    queryset_list = InterventionP.objects.active()
    if request.user.is_staff or request.user.is_superuser:
        queryset_list = InterventionP.objects.all()
        query = request.GET.get("q")
        if query:
            queryset_list = queryset_list.filter(panneM__icontains=query)

        paginator = Paginator(queryset_list, 2)
        page_request_var = "page"
        page = request.GET.get(page_request_var)
        try:
            queryset_list = paginator.page(page)
        except PageNotAnInteger:
            queryset = paginator.page(1)
        except EmptyPage:
            queryset = paginator.page(paginator.num_pages)

            context = {"object_list": queryset,
                       "title": "List",
                       "page_request_var": page_request_var,
                       "tody": today}
    return render(request, "intervention.html", context)


#############################################################################


def Demande(request, username):
    if request.method == 'POST':
        message = request.POST['message']

        send_mail("Demande d'intervention",
                  message,
                  settings.EMAIL_HOST_USER,
                  ['hammamisiwar.m16@gmail.com',
                   'kalboussikalboussi1997@gmail.com'],
                  fail_silently=False)

    return render(request, 'alerte.html', {'ur': username})





