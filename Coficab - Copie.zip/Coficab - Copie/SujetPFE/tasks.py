from celery import shared_task
from celery import Celery
from django.db.models import Max
from django.db.models import Min

from datetime import datetime, timedelta

import random

from Coficab.celery import app
from SujetPFE import models

celery = Celery('tasks', broker='amqp://guest@localhost//')  # !
from django.core.mail import send_mail
from time import sleep


@shared_task
def sleepy(duration):
    sleep(duration)
    return None


@shared_task
def send_email_task():
    # var = UtilisateurC.objects.filter(mail=UtilisateurC.Adr_mail)
    sleep(0.5)
    send_mail('Alerte de Panne',
              'Il existe une panne',
              'kalboussimeriem@gmail.com',
              ['hammamisiwar.m16@gmail.com', 'kalboussikalboussi1997@gmail.com'])
    ##################################
    """send_mail('Alerte de Panne',
              'Il existe une panne',
              'kalboussimeriem@gmail.com',
              {'groupe': var})"""

    return None


########################################
