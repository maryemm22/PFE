from django.apps import AppConfig


class SujetpfeConfig(AppConfig):
    name = 'SujetPFE'
